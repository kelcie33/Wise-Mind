<?php
namespace App\View\Helper;

use Cake\View\Helper;

class GeshiHelper extends Helper
{
  public static function highlightText($text)
  {
    echo nl2br($text);
  }  
}
