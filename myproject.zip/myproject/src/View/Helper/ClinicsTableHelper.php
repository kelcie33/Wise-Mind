<?php
namespace App\View\Helper;

use Cake\View\Helper;

class ClinicsTableHelper extends Helper
{
  
}
?>