<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Sounds Controller
 *
 * @property \App\Model\Table\SoundsTable $Sounds
 */
class SoundsController extends AppController
{
    /**
     * Index method
     *
     * @return void
     */
    public function index()
    {
        $this->set('sounds', $this->paginate($this->Sounds));
        $this->set('_serialize', ['sounds']);
    }

    /**
     * View method
     *
     * @param string|null $id Sound id.
     * @return void
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function view($id = null)
    {
        $sound = $this->Sounds->get($id, [
            'contain' => []
        ]);
        $this->set('sound', $sound);
        $this->set('_serialize', ['sound']);
    }

    /**
     * Add method
     *
     * @return void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $sound = $this->Sounds->newEntity();
        if ($this->request->is('post')) {
            $sound = $this->Sounds->patchEntity($sound, $this->request->data);
            if ($this->Sounds->save($sound)) {
                $this->Flash->success(__('The sound has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The sound could not be saved. Please, try again.'));
            }
        }
        $this->set(compact('sound'));
        $this->set('_serialize', ['sound']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Sound id.
     * @return void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $sound = $this->Sounds->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $sound = $this->Sounds->patchEntity($sound, $this->request->data);
            if ($this->Sounds->save($sound)) {
                $this->Flash->success(__('The sound has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The sound could not be saved. Please, try again.'));
            }
        }
        $this->set(compact('sound'));
        $this->set('_serialize', ['sound']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Sound id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $sound = $this->Sounds->get($id);
        if ($this->Sounds->delete($sound)) {
            $this->Flash->success(__('The sound has been deleted.'));
        } else {
            $this->Flash->error(__('The sound could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
