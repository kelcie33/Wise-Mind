<?php

App::uses('Shell', 'Console');
class AppShell extends Shell {
}
?>